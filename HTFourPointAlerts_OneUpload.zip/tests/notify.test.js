const fs=require('fs'),assert=require('assert'),vm=require('vm');
const src='app/src/main/java/com/htlive/monitor/';
const get=n=>fs.readFileSync(src+n+'.java','utf8');
const service=get('MonitorService'),notifier=get('AlertNotifier'),alarm=get('ReminderReceiver'),details=get('MatchData'),ai=get('AiReview');
const app=get('MainActivity'),policy=get('AlertPolicy');
for(const m of [3,15,28,40])assert(policy.includes([3,15,28,40].join(',')),'exact four marks');
assert(alarm.includes('{-1,3,15,28,40}'), 'wake-up alarms retained');
assert(alarm.includes('match.optInt("minute",0)<=mark+2'),'no late stale checkpoint from alarm');
assert(service.includes('for(int mark:AlertPolicy.MARKS)'), 'four minute notifications via policy');
assert(notifier.includes('post(ctx,"第"+mark+"分钟定点复核"'), 'minute banners');
assert(notifier.includes('saveCheckpoint(Context ctx'), 'record source and trend');
assert(notifier.includes('bigText(expanded)'), 'full match summary in notification');
for(const f of ['xg','shots','on','box','danger']){
 assert(details.includes('compare(x,"'+f+'")'), f+' appears in short summary');
}
assert(details.includes('new String[]{"five","ten"}'),'5/10 min windows retained');
assert(details.includes('有效快照不足'),'no invented stat changes');
assert(ai.includes('api.openai.com/v1/responses'),'AI API unchanged');
assert(app.includes('getAiKey()'),'AI setup UI unchanged');
assert(service.includes('pendingAi.add(new AiTask('),'AI still updates allowed checkpoint alerts');
assert(service.includes('boolean relevant=!marksSent.isEmpty()'),'no AI calls for suppressed risk signals');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
for(const s of [...html.matchAll(/<script(?: [^>]*)?>([\s\S]*?)<\/script>/g)])new vm.Script(s[1]);
console.log('PASS: four checkpoints with detailed xG/stats, original AI + screenshot UI retained');
