package org.json;
import java.util.Map;
import java.util.LinkedHashMap;
/** Minimal test-only stand-in. NOT part of the Android app. */
public class JSONObject {
  private final Map<String,Object> map=new LinkedHashMap<>();
  public JSONObject put(String key,Object value){map.put(key,value);return this;}
  public boolean has(String key){return map.containsKey(key);}
  public boolean isNull(String key){return !map.containsKey(key)||map.get(key)==null;}
  public String optString(String key){return optString(key,"");}
  public String optString(String key,String fallback){Object o=map.get(key);return o==null?fallback:o.toString();}
  public int optInt(String key){return optInt(key,0);}
  public int optInt(String key,int fallback){Object o=map.get(key);return o instanceof Number?((Number)o).intValue():fallback;}
  public double optDouble(String key,double fallback){Object o=map.get(key);return o instanceof Number?((Number)o).doubleValue():fallback;}
  public long optLong(String key){return optLong(key,0L);}
  public long optLong(String key,long fallback){Object o=map.get(key);return o instanceof Number?((Number)o).longValue():fallback;}
  public boolean optBoolean(String key){Object o=map.get(key);return o instanceof Boolean?(Boolean)o:false;}
  public JSONObject optJSONObject(String key){Object o=map.get(key);return o instanceof JSONObject?(JSONObject)o:null;}
}
