package com.htlive.monitor;

public final class AlertPolicyTest {
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        check(java.util.Arrays.equals(AlertPolicy.MARKS,new int[]{3,15,28,40}),"four marks");
        for(int mark:AlertPolicy.MARKS){
            check(AlertPolicy.checkpointDue(mark-1,mark,mark),"just entered milestone "+mark);
            check(AlertPolicy.checkpointDue(-1,mark,mark),"started exactly at milestone "+mark);
            check(AlertPolicy.checkpointDue(-1,mark+1,mark),"started just after milestone "+mark);
            check(AlertPolicy.checkpointDue(-1,mark+2,mark),"tolerate up to two minutes of delay "+mark);
            check(!AlertPolicy.checkpointDue(-1,mark+3,mark),"no very late catch-up on initial snapshot "+mark);
            check(!AlertPolicy.checkpointDue(mark-1,mark+5,mark),"no very late catch-up from a stale snapshot "+mark);
            check(!AlertPolicy.checkpointDue(mark,mark,mark),"no duplicate marker "+mark);
            check(!AlertPolicy.checkpointDue(mark-1,mark-1,mark),"no early marker "+mark);
        }
        check(!AlertPolicy.checkpointDue(2,4,5),"never send an unconfigured milestone");
        check(AlertPolicy.goalOccurred(false,true,true,0,0,1,0),"home goal");
        check(AlertPolicy.goalOccurred(false,true,true,1,0,1,1),"away goal");
        check(!AlertPolicy.goalOccurred(false,true,true,1,1,1,0),"disallowed goal");
        check(!AlertPolicy.goalOccurred(true,true,true,0,0,1,0),"first poll baseline");
        check(!AlertPolicy.goalOccurred(false,false,true,0,0,1,0),"no previous baseline");
        check(!AlertPolicy.goalOccurred(false,true,false,0,0,1,0),"not first half");
        System.out.println("PASS: fixed milestones and correctly observed first-half goals");
    }
}
