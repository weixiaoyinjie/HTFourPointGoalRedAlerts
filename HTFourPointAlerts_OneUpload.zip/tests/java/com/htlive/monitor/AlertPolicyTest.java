package com.htlive.monitor;

public final class AlertPolicyTest {
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        check(java.util.Arrays.equals(AlertPolicy.MARKS,new int[]{3,15,28,40}),"four marks");
        for(int mark:AlertPolicy.MARKS){
            check(AlertPolicy.checkpointDue(mark-1,mark,mark),"just entered milestone "+mark);
            check(AlertPolicy.checkpointDue(-1,mark,mark),"started exactly at milestone "+mark);
            check(AlertPolicy.checkpointDue(-1,mark+1,mark),"started just after milestone "+mark);
            check(AlertPolicy.checkpointDue(-1,mark+2,mark),"tolerate up to two minutes of delay "+mark);
            check(!AlertPolicy.checkpointDue(-1,mark+3,mark),"no very late catch-up on initial snapshot "+mark);
            check(!AlertPolicy.checkpointDue(mark-1,mark+5,mark),"no very late catch-up from a stale snapshot "+mark);
            check(!AlertPolicy.checkpointDue(mark,mark,mark),"no duplicate marker "+mark);
            check(!AlertPolicy.checkpointDue(mark-1,mark-1,mark),"no early marker "+mark);
        }
        check(!AlertPolicy.checkpointDue(2,4,5),"never send an unconfigured milestone");
        check(AlertPolicy.goalOccurred(false,true,true,0,0,1,0),"home goal");
        check(AlertPolicy.goalOccurred(false,true,true,1,0,1,1),"away goal");
        check(!AlertPolicy.goalOccurred(false,true,true,1,1,1,0),"disallowed goal");
        check(!AlertPolicy.goalOccurred(true,true,true,0,0,1,0),"first poll baseline");
        check(!AlertPolicy.goalOccurred(false,false,true,0,0,1,0),"no previous baseline");
        check(!AlertPolicy.goalOccurred(false,true,false,0,0,1,0),"not first half");
        long now=1_000_000L;
        check(AlertPolicy.checkpointFresh(now,now-30_000L,"1H",15,15),"fresh actual checkpoint");
        check(AlertPolicy.checkpointFresh(now,now-60_000L,"1H",17,15),"max age and minute window");
        check(!AlertPolicy.checkpointFresh(now,now-60_001L,"1H",15,15),"reject old successful fixture sample");
        check(!AlertPolicy.checkpointFresh(now,0,"1H",15,15),"do not trust missing timestamp");
        check(!AlertPolicy.checkpointFresh(now,now-30_000L,"1H",18,15),"never replay old milestone");
        check(!AlertPolicy.checkpointFresh(now,now-30_000L,"HT",15,15),"reject halftime");
        check(!AlertPolicy.checkpointFresh(now,now-30_000L,"1H",14,15),"reject future milestone");
        check(!AlertPolicy.checkpointFresh(now,now+5_001L,"1H",15,15),"reject implausible future sample");
        check(AlertPolicy.combinedRedCount(1,0)==1,"stats first red");
        check(AlertPolicy.newRedCard(false,true,0,AlertPolicy.combinedRedCount(1,0)),"notify one red from stats");
        check(!AlertPolicy.newRedCard(false,true,1,AlertPolicy.combinedRedCount(1,1)),"later red event must NOT duplicate");
        check(AlertPolicy.newRedCard(false,true,0,AlertPolicy.combinedRedCount(0,1)),"notify red event first");
        check(!AlertPolicy.newRedCard(false,true,1,AlertPolicy.combinedRedCount(1,1)),"later stat must NOT duplicate");
        check(AlertPolicy.newRedCard(false,true,1,AlertPolicy.combinedRedCount(2,1)),"second genuine red after first");
        check(AlertPolicy.redEventIdentity(23,55,28,0,2).equals(AlertPolicy.redEventIdentity(23,55,29,0,3)),
            "same player's red and second-yellow are one event despite corrected minute");
        check(!AlertPolicy.redEventIdentity(23,55,28,0,2).equals(AlertPolicy.redEventIdentity(23,56,28,0,3)),
            "two different players are distinct red cards");
        check(!AlertPolicy.newRedCard(true,true,0,2),"first poll establishes baseline");
        check(!AlertPolicy.newRedCard(false,false,0,1),"newly added fixture establishes baseline");
        System.out.println("PASS: milestones, stale-alarm prevention, red-card reconciliation and 1H goal rules");
    }
}
