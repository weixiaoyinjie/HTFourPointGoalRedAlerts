package com.htlive.monitor;
import org.json.JSONObject;
public class MainScoreRiskEngineTest {
  static long t=1_800_000_000_000L;
  static void yes(boolean x,String message){if(!x)throw new AssertionError(message);}
  static JSONObject team(double xg,int shots,int on,int box,int pos){
    return new JSONObject().put("xg",xg).put("shots",shots).put("on",on).put("box",box).put("pos",pos);
  }
  static JSONObject match(int minute,int h,int a,JSONObject hs,JSONObject as){
    return new JSONObject().put("id","888").put("status","1H").put("minute",minute)
      .put("h",h).put("a",a).put("lastStatsAt",t).put("mainPick","1-0")
      .put("stats",new JSONObject().put("available",true).put("home",hs).put("away",as));
  }
  static void kind(JSONObject m,String expected){
    yes(expected.equals(m.optJSONObject("mainPickRisk").optString("kind")),"Expected "+expected);
  }
  static JSONObject run(JSONObject n,JSONObject p,String pick)throws Exception{
    JSONObject risk=MainScoreRiskEngine.analyze(n,p,pick,t);
    n.put("mainPickRisk",risk);
    return risk;
  }
  public static void main(String[] args)throws Exception{
    JSONObject h=team(.07,5,0,2,37),a=team(.37,5,2,3,63);
    JSONObject x=match(24,0,0,h,a);
    JSONObject r=run(x,null,"1-0");
    yes(r.optBoolean("notify")&&"away".equals(r.optString("side")),"5-5 shots, away xG/on dominance must notify");
    yes(MainScoreRiskEngine.shouldNotify(x,null,t),"initial advantage must post");
    JSONObject reverse=match(24,0,0,team(.37,5,2,3,63),team(.07,5,0,2,37));
    yes("home".equals(run(reverse,null,"1-0").optString("side")),"symmetric home dominance must notify");
    JSONObject seventy=match(14,0,0,team(.07,1,0,1,30),team(.10,3,0,1,70));
    yes("away".equals(run(seventy,null,"1-0").optString("side")),"70/30 possession, 3/1 shot advantage must notify");
    JSONObject dull=match(29,0,0,team(.06,2,0,1,51),team(.08,2,0,1,49));
    yes("quiet".equals(run(dull,null,"1-0").optString("kind")),"1-0 pick, 0-0 and dull by minute 29 must notify");
    JSONObject noQuiet=match(29,0,0,team(.06,2,0,1,51),team(.08,2,0,1,49));
    yes(!"quiet".equals(run(noQuiet,null,"0-0").optString("kind")),"0-0 pick should not warn about dull 0-0");
    JSONObject opening=match(4,0,0,team(.02,1,0,0,51),team(.02,0,0,0,49));
    yes(!run(opening,null,"0-0").optBoolean("notify"),"0-0 at 4 min should not falsely count as reached target");
    JSONObject goal=match(18,1,0,team(.20,3,1,1,58),team(.12,2,0,1,42));
    yes("justHit".equals(run(goal,null,"1-0").optString("kind")),"arrive with 1-0, immediate target alert");
    JSONObject post=match(19,1,0,team(.21,4,1,2,59),team(.12,2,0,1,41));
    JSONObject old=goal;old.put("lastMainRiskNotifyAt",t-240_000);
    yes("atScoreNewAttack".equals(run(post,old,"1-0").optString("kind")),"shot added with unchanged 1-0 -> post-goal alert");
    yes(MainScoreRiskEngine.shouldNotify(post,old,t),"genuinely fresh post-goal effort should warn");
    JSONObject stagnant=match(21,1,0,team(.20,3,1,1,58),team(.12,2,0,1,42));
    yes(!"atScoreNewAttack".equals(run(stagnant,goal,"1-0").optString("kind")),"no post-goal pressure when counts unchanged");
    JSONObject bad=match(33,1,1,team(.22,5,2,2,50),team(.38,5,2,3,50));
    yes("broken".equals(run(bad,post,"1-0").optString("kind")),"score 1-1 irreversibly breaks 1-0");
    JSONObject unknown=match(32,0,0,team(.06,2,0,1,50),team(.08,2,0,1,50));
    unknown.put("lastStatsAt",t-200_000);
    yes(!run(unknown,dull,"1-0").optBoolean("notify"),"stale stats may not generate quiet risk");
    yes(MainScoreRiskEngine.validPick("1-0")&&!MainScoreRiskEngine.validPick("9:0"),"score syntax");
    System.out.println("PASS: nine score-aware dynamic cases including 5/5 shots + 0/2 on + xG .07/.37, target reached, dull, freshness, reverse");
  }
}
