/* Run with: node tests/parser.test.js (no network or packages needed). */
const assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm');
const context={};
vm.runInNewContext(fs.readFileSync('app/src/main/assets/import_parser.js','utf8'),context);
const {parse,match,readFixtureId}=context.HTImportParser;
const fixtures=[
 {id:'1632035',home:'Deportivo Recoleta',away:'Rubio NU',kickoff:'2026-10-16T22:20:00+00:00',league:'Paraguay'},
 {id:'981234',home:'AC Milan',away:'Roma',kickoff:'2026-10-16T23:00:00+00:00',league:'Italy'},
 {id:'1632036',home:'Wrong name',away:'Other name',kickoff:'2026-10-16T20:20:00+00:00'}
];
const txt=`2026-10-16 19:20 开赛\nDeportivo Recoleta vs Rubio NU\nFixture ID: 1632035`;
function parsed(s){return parse({ocrText:s,ocrEdited:true});}
assert.equal(parsed(txt).items.length,1);
assert.equal(parsed(txt).items[0].fixtureId,'1632035');
assert.equal(match(parsed(txt),fixtures).matched[0].id,'1632035');
const splitId=parsed(`2026-10-16 19:20 开赛\nDeportivo Recoleta vs Rubio NU\nFixture ID:\n1632035`);
assert.equal(splitId.items[0].fixtureId,'1632035');
const idOnly=parsed(`2026-10-16 19:20 开赛\nFixture ID: 1632035`);
assert.equal(idOnly.items.length,1);
assert.equal(idOnly.items[0].fixtureId,'1632035');
assert.equal(match(idOnly,fixtures).matched[0].id,'1632035');
assert.equal(match(parsed(txt.replace('1632035','1632036')),fixtures).matched.length,0,'Wrong ID cannot be guessed from names');
assert.equal(match(parsed(txt.replace('19:20','18:20')),fixtures).matched.length,0,'Incorrect time must reject ID');
assert.equal(match(parsed(txt.replace('2026-10-16','2026-10-17')),fixtures).matched.length,0,'Incorrect date must reject ID');
const named=parsed(`2026-10-16 19:20 开赛\nDeportivo Recoleta vs Rubio NU`);
assert.equal(match(named,fixtures).matched.length,1,'No-ID legacy match still works');
const many=parsed(`2026-10-16 19:20 开赛\nDeportivo Recoleta vs Rubio NU\nFixture ID: 1632035\n2026-10-16 20:00 开赛\nAC Milan vs Roma\nFixture ID: 981234`);
assert.equal(many.items.length,2);
assert.equal(match(many,fixtures).matched.length,2);
const withBBox={ocrEdited:false,ocrLines:[
 {t:'Fixture ID: 1632035',x:90,y:160,h:21,color:'white'},
 {t:'Deportivo Recoleta vs Rubio NU',x:90,y:110,h:31,color:'white'},
 {t:'2026-10-16 19:20 开赛',x:90,y:40,h:42,color:'green'}
 ],ocrText:'Fixture ID: 1632035\n2026-10-16 19:20 开赛\nDeportivo Recoleta vs Rubio NU'};
assert.equal(parse(withBBox).items[0].fixtureId,'1632035');
assert.equal(readFixtureId('Fixture ID: 1632035'),'1632035');
assert.equal(readFixtureId('2026-10-16 19:20'),'');
console.log('PASS: 11 parser + fixture matching assertions; screenshot sample accepted; bad ID/time/date rejected');
