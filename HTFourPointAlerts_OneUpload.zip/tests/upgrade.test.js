const fs=require('fs'),assert=require('assert'),crypto=require('crypto'),vm=require('vm');
const base='app/src/main/';const read=n=>fs.readFileSync(base+n);
const html=read('assets/index.html').toString('utf8');
const parser=read('assets/import_parser.js');
const get=n=>fs.readFileSync(base+'java/com/htlive/monitor/'+n+'.java','utf8');
const svc=get('MonitorService'),alarm=get('ReminderReceiver'),ai=get('AiReview'),activity=get('MainActivity');
const cfg=fs.readFileSync('app/build.gradle','utf8');
const manifest=fs.readFileSync(base+'AndroidManifest.xml','utf8');
for(const [asset,expected] of [
 ['assets/import_parser.js','6328c562c1e411ade805f996faa8cdb825ae2f28e9e74a8e216d4fc01d187933'],
 ['java/com/htlive/monitor/ApiClient.java','999a2ef6d78c81e73bc0b261adab7b71d0860a3cf77a53343144c437406ba41b'],
 ['java/com/htlive/monitor/AiReview.java','39d70826d8c84d3009271ce13f20d65cace7f0445e4daba1b7b6cd7eb8defd99']
])assert.strictEqual(crypto.createHash('sha256').update(read(asset)).digest('hex'),expected,`${asset} must remain byte-identical to source ZIP`);
assert(html.includes('id="aiKey"')&&html.includes('id="saveAiKey"'));
assert(html.includes('<option value="30">')&&html.includes('checkpoints.slice(0,24)'));
const inlineScripts=[...html.matchAll(/<script(?: [^>]*)?>([\s\S]*?)<\/script>/g)];
const unchangedScripts=inlineScripts.map(s=>s[1]).join('');
assert.strictEqual(crypto.createHash('sha256').update(unchangedScripts).digest('hex'),
    '8a6be63a0431a05ea5d682e61d66ef44135809025de13768ed1efc597c9f33cd',
    'all original inline JavaScript must remain byte-identical');
for(const s of inlineScripts)new vm.Script(s[1]);
assert(html.includes('过期定点提醒不补发'),'corrected notification explanation present');
assert(!html.includes('原有B/C级双向攻势预警继续运行'),'misleading old alert explanation removed');
assert(alarm.includes('{-1,3,15,28,40}'));
assert(svc.includes('if(!ended)next.put(now)'));
assert(svc.includes('ReminderReceiver.cancelFinished(this,finishedIds)'));
assert(svc.includes('Math.max(30,Math.min(300'));
assert(svc.includes('AiReview.review(task.match,task.key)'));
assert(ai.includes('api.openai.com/v1/responses'));
assert(activity.includes('getAiKey()')&&activity.includes('autoPruned'));
assert(cfg.includes("applicationId 'com.htlive.monitor.checkpoints'"));
assert(!cfg.includes("applicationId 'com.htlive.monitor.multimatch'"));
assert(manifest.includes('HT 四点提醒（独立版）'));
console.log('PASS: original JS logic/OCR/football/AI clients byte-identical, corrected explanatory text');
