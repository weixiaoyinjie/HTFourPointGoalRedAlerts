package com.htlive.monitor;

/** Pure, side-effect-free dispatch rules for the limited-alert companion app. */
final class AlertPolicy {
    static final int[] MARKS={3,15,28,40};
    private AlertPolicy(){}

    /** Never invent the four milestones from a cached or pre-kickoff clock.
     *  A new monitor may legitimately join during the current mark's minute. */
    static boolean checkpointDue(int previousMinute,int minute,int mark){
        if(!isMark(mark) || minute<mark || previousMinute>=mark)return false;
        // Android/API lag may postpone a node slightly, but never replay it
        // many minutes later when a device wakes from deep sleep.
        return minute<=mark+2;
    }
    private static boolean isMark(int mark){
        for(int m:MARKS)if(m==mark)return true;
        return false;
    }

    /** Downward score corrections (e.g. disallowed goal) are not a new goal. */
    static boolean goalOccurred(boolean firstCycle,boolean hadPrevious,boolean firstHalf,
                                int prevHome,int prevAway,int home,int away){
        return !firstCycle && hadPrevious && firstHalf &&
            (home>prevHome || away>prevAway);
    }
}
