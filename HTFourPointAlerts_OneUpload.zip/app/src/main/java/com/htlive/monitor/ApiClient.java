package com.htlive.monitor;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class ApiClient {
    private ApiClient() {}
    public static JSONObject get(String path, String key) throws Exception {
        if (key == null || key.trim().isEmpty()) throw new Exception("请先填写 API-FOOTBALL Key");
        if (path == null || !path.matches("^(fixtures(?:/statistics|/events)?)(\\?[A-Za-z0-9_=&%+./-]*)?$"))
            throw new Exception("不支持的接口路径");
        HttpURLConnection conn = (HttpURLConnection) new URL("https://v3.football.api-sports.io/" + path).openConnection();
        try {
            conn.setRequestMethod("GET");
            conn.setRequestProperty("x-apisports-key", key);
            conn.setRequestProperty("Accept", "application/json");
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(17000);
            conn.setUseCaches(false);
            int status = conn.getResponseCode();
            InputStream stream = status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream();
            if (stream == null) throw new Exception("API 请求失败 HTTP " + status);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream src = stream) {
                byte[] buf = new byte[8192]; int read;
                while ((read=src.read(buf)) != -1) {
                    out.write(buf,0,read);
                    if (out.size() > 10_000_000) throw new Exception("API 响应过大");
                }
            }
            String text = out.toString(StandardCharsets.UTF_8.name());
            JSONObject root = new JSONObject(text);
            if (status < 200 || status >= 300) throw new Exception("API HTTP " + status + ": " + text.substring(0,Math.min(180,text.length())));
            Object errors = root.opt("errors");
            if (errors instanceof JSONObject && ((JSONObject)errors).length()>0) throw new Exception("API 错误: " + errors.toString());
            if (errors instanceof JSONArray && ((JSONArray)errors).length()>0) throw new Exception("API 错误: " + errors.toString());
            return root;
        } finally { conn.disconnect(); }
    }
}
