package com.htlive.monitor;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Map;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MonitorService extends Service {
    private static final String LIVE_CHANNEL="ht_live_tracking";
    private static final String ALERT_CHANNEL="ht_event_alerts";
    private static final int LIVE_ID=2810;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ExecutorService aiWorker=Executors.newFixedThreadPool(2);
    private final Semaphore aiSlots=new Semaphore(2);
    private final Object snapshotLock=new Object();
    private static final class AiTask {
        String id,key,riskType;
        JSONObject match;
        ArrayList<Integer> marks;
        long at;
        AiTask(String i,String k,JSONObject m,String r,ArrayList<Integer> marks,long at){
            this.id=i;key=k;match=m;riskType=r;this.marks=new ArrayList<>(marks);this.at=at;
        }
    }
    private SharedPreferences pref;
    private volatile boolean active=false;
    private int interval=120;
    private int notifyId=3000;
    private int apiCalls=0;
    private volatile boolean firstCycle=true;
    private long lastLoggedErrorAt=0L;
    private String lastLoggedError="";

    @Override public void onCreate(){super.onCreate();pref=getSharedPreferences("ht_monitor",MODE_PRIVATE);makeChannels(this);}
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && "STOP".equals(intent.getAction())){stopMonitor();return START_NOT_STICKY;}
        if(!active){
            interval=Math.max(30,Math.min(300,pref.getInt("interval",60)));
            active=true;
            firstCycle=true;
            pref.edit().putBoolean("running",true).apply();
            try {
                Notification n=liveNotification("准备读取已选择的比赛 · 每"+interval+"秒更新");
                if(Build.VERSION.SDK_INT>=34) startForeground(LIVE_ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
                else startForeground(LIVE_ID,n);
            } catch(Exception e){
                active=false;pref.edit().putBoolean("running",false).apply();stopSelf();return START_NOT_STICKY;
            }
            tick();
        }
        return START_NOT_STICKY;  // never auto-restart after device kill
    }
    private void tick(){
        if(!active)return;
        worker.execute(()->{
            try{ pollOnce(); }
            catch(Exception e){
                pref.edit().putString("lastError",e.getMessage()).apply();
                String issue=String.valueOf(e.getMessage());
                long at=System.currentTimeMillis();
                if(!issue.equals(lastLoggedError) || at-lastLoggedErrorAt>5*60_000L){
                    record("接口异常",issue);lastLoggedError=issue;lastLoggedErrorAt=at;
                }
                updateSnapshotError(e.getMessage());
                updateOngoingNotification("数据请求失败，"+interval+"秒后重试");
            }
            // Honour interval changes without restarting the existing foreground service.
            interval=Math.max(30,Math.min(300,pref.getInt("interval",interval)));
            if(active)handler.postDelayed(this::tick,interval*1000L);
        });
    }
    private void updateSnapshotError(String error){
        try {
            synchronized(snapshotLock){
                JSONObject snap=new JSONObject(pref.getString("snapshot","{}"));
                snap.put("error",error).put("updatedAt",System.currentTimeMillis());
                pref.edit().putString("snapshot",snap.toString()).apply();
            }
        }catch(Exception ignored){}
    }
    private void pollOnce() throws Exception {
        String csv=pref.getString("watchIds","");
        String key=pref.getString("apiKey","");
        if(csv.isEmpty()||key.isEmpty()){stopMonitor();return;}
        JSONArray fixtures=ApiClient.get("fixtures?ids="+csv.replace(',','-')+"&timezone=America%2FArgentina%2FBuenos_Aires",key).optJSONArray("response");
        apiCalls++;
        if(fixtures==null || fixtures.length()==0)throw new Exception("找不到已选比赛：请核对 API fixture ID / 赛事覆盖");
        JSONObject previous=new JSONObject(pref.getString("snapshot","{}"));
        JSONObject mainPicks=new JSONObject(pref.getString("mainPicks","{}"));
        Map<String,JSONObject> old=new HashMap<>();
        JSONArray priorItems=previous.optJSONArray("matches");
        if(priorItems!=null)for(int i=0;i<priorItems.length();i++){
            JSONObject item=priorItems.optJSONObject(i);
            if(item!=null)old.put(item.optString("id"),item);
        }
        JSONArray next=new JSONArray();
        ArrayList<AiTask> pendingAi=new ArrayList<>();
        Set<String> finishedIds=new HashSet<>();
        int activeH=0, finishedH=0, future=0;
        for(int i=0;i<fixtures.length();i++){
            JSONObject f=fixtures.optJSONObject(i);if(f==null)continue;
            JSONObject fInfo=f.optJSONObject("fixture");if(fInfo==null)continue;
            String id=String.valueOf(fInfo.optInt("id"));
            JSONObject oldItem=old.get(id);
            JSONObject statusObj=fInfo.optJSONObject("status");
            String status=statusObj==null?"?":statusObj.optString("short","?");
            int minute=statusObj==null?0:statusObj.optInt("elapsed",0);
            JSONObject teams=f.optJSONObject("teams");
            JSONObject home=teams==null?null:teams.optJSONObject("home");
            JSONObject away=teams==null?null:teams.optJSONObject("away");
            int homeId=home==null?0:home.optInt("id");
            int awayId=away==null?0:away.optInt("id");
            JSONObject goal=f.optJSONObject("goals");
            int h=goal==null||goal.isNull("home")?0:goal.optInt("home");
            int a=goal==null||goal.isNull("away")?0:goal.optInt("away");
            boolean live="1H".equals(status);
            // Never infer halftime from elapsed >=45: 45+ stoppage can continue in 1H.
            boolean ended=MatchLifecycle.shouldPrune(status);
            if(live)activeH++;else if(ended){finishedH++;finishedIds.add(id);}else future++;
            JSONObject now=new JSONObject();
            now.put("id",id).put("home",home==null?"主队":home.optString("name","主队"))
               .put("away",away==null?"客队":away.optString("name","客队"))
               .put("status",status).put("minute",minute).put("h",h).put("a",a)
               .put("fixtureSampledAt",System.currentTimeMillis())
               .put("league",f.optJSONObject("league")==null?"":f.optJSONObject("league").optString("name",""))
               .put("kickoff",fInfo.optString("date",""));
            String mainPick=mainPicks.optString(id,"");
            if(MainScoreRiskEngine.validPick(mainPick))now.put("mainPick",mainPick);
            if(oldItem!=null){
                if(oldItem.has("stats")) now.put("stats",oldItem.get("stats"));
                if(oldItem.has("history"))now.put("history",oldItem.get("history"));
                if(oldItem.has("events"))now.put("events",oldItem.get("events"));
                if(oldItem.has("lastPressureNotify"))now.put("lastPressureNotify",oldItem.get("lastPressureNotify"));
                if(oldItem.has("lastGoalNotifyAt"))now.put("lastGoalNotifyAt",oldItem.get("lastGoalNotifyAt"));
                if(oldItem.has("lastGoalNotifyLevel"))now.put("lastGoalNotifyLevel",oldItem.get("lastGoalNotifyLevel"));
                if(oldItem.has("lastGoalNotifySide"))now.put("lastGoalNotifySide",oldItem.get("lastGoalNotifySide"));
                if(oldItem.has("lastGoalNotifyKind"))now.put("lastGoalNotifyKind",oldItem.get("lastGoalNotifyKind"));
                if(oldItem.has("lastRedAt"))now.put("lastRedAt",oldItem.get("lastRedAt"));
                if(oldItem.has("redNotifiedTotal"))now.put("redNotifiedTotal",oldItem.get("redNotifiedTotal"));
                if(oldItem.has("trend"))now.put("trend",oldItem.get("trend"));
                if(oldItem.has("lastStatsAt"))now.put("lastStatsAt",oldItem.get("lastStatsAt"));
                if(oldItem.has("lastStatsSampleAt"))now.put("lastStatsSampleAt",oldItem.get("lastStatsSampleAt"));
                if(oldItem.has("lastStatsChangedAt"))now.put("lastStatsChangedAt",oldItem.get("lastStatsChangedAt"));
                if(oldItem.has("lastDisruptionAt"))now.put("lastDisruptionAt",oldItem.get("lastDisruptionAt"));
                if(oldItem.has("lastEventsAt"))now.put("lastEventsAt",oldItem.get("lastEventsAt"));
                if(oldItem.has("lastDataAlertAt"))now.put("lastDataAlertAt",oldItem.get("lastDataAlertAt"));
                if(oldItem.has("aiReview"))now.put("aiReview",oldItem.get("aiReview"));
                if(oldItem.has("aiReviewAt"))now.put("aiReviewAt",oldItem.get("aiReviewAt"));
                if(oldItem.has("aiReviewCount"))now.put("aiReviewCount",oldItem.get("aiReviewCount"));
                if(oldItem.has("aiReviewMinute"))now.put("aiReviewMinute",oldItem.get("aiReviewMinute"));
                if(oldItem.has("lastMainRiskNotifyAt"))now.put("lastMainRiskNotifyAt",oldItem.get("lastMainRiskNotifyAt"));
                if(oldItem.has("mainPickRisk"))now.put("mainPickRisk",oldItem.get("mainPickRisk"));
            }
            // A changed user score immediately invalidates cached AI analysis.
            if(oldItem!=null && !mainPick.equals(oldItem.optString("mainPick",""))){
                now.remove("aiReview");now.put("aiReviewAt",0L).put("aiReviewCount",0)
                   .put("aiReviewMinute",-1).put("lastMainRiskNotifyAt",0L);
            }
            // The old half's attack window and AI conclusion cannot survive a goal.
            // This applies even if the next statistics call is throttled or fails.
            if(oldItem!=null && (h!=oldItem.optInt("h",h) || a!=oldItem.optInt("a",a))){
                now.remove("history");now.remove("aiReview");
                now.put("lastStatsSampleAt",0L);
            }
            if(live){
                try{
                    // /fixtures?ids includes live statistics for supported leagues/plans.
                    // Embedded data is preferred: one network round trip for multiple matches.
                    JSONArray embeddedStats=f.optJSONArray("statistics");
                    JSONObject stats=MatchData.combine(embeddedStats,homeId,awayId);
                    boolean embedded=stats.optBoolean("available",false);
                    long fetchAt=System.currentTimeMillis();
                    boolean due=oldItem==null || fetchAt-oldItem.optLong("lastStatsAt",0L)>=60_000L;
                    boolean fetched=embedded;
                    if(!embedded && due){
                        JSONObject result=ApiClient.get("fixtures/statistics?fixture="+id+"&half=true",key);
                        apiCalls++;
                        stats=MatchData.combine(result.optJSONArray("response"),homeId,awayId);
                        fetched=true;
                    }else if(!embedded && oldItem!=null && oldItem.has("stats")){
                        stats=oldItem.optJSONObject("stats");
                    }
                    boolean statsChanged=oldItem==null || oldItem.optJSONObject("stats")==null ||
                        !stats.toString().equals(oldItem.optJSONObject("stats").toString());
                    if(fetched){
                        now.put("lastStatsAt",fetchAt);
                        if(statsChanged)now.put("lastStatsChangedAt",fetchAt);
                    }
                    now.put("statsSource",embedded?"批量赛况":fetched?"单场统计":"单场统计缓存（1分钟节流）");
                    now.put("stats",stats);
                    // Do not emit here: API statistics and /fixtures/events can
                    // report the SAME red card on different polling cycles.
                    // Reconcile both counts once, after both responses are read.
                    boolean scoreReset=oldItem!=null && (h!=oldItem.optInt("h")||a!=oldItem.optInt("a"));
                    // Avoid treating repeated 30-second reads as independent fresh samples.
                    boolean sampleDue=oldItem==null || fetchAt-oldItem.optLong("lastStatsSampleAt",0)>=55_000L;
                    if(stats!=null && stats.optBoolean("available") && fetched && sampleDue){
                        if(scoreReset)now.remove("aiReview");
                        updateTrend(now,scoreReset?null:oldItem,minute);
                        now.put("lastStatsSampleAt",fetchAt);
                    }
                    else if(stats==null || !stats.optBoolean("available"))now.put("trend","无统计覆盖");
                    if(stats!=null && stats.optBoolean("available") &&
                   System.currentTimeMillis()-now.optLong("lastStatsAt",0L)>90_000L)
                     now.put("dataError","数据已超过90秒未刷新，停止使用缓存判断");
                    else now.remove("dataError");
                }catch(Exception ex){ now.put("stats",new JSONObject().put("available",false)); now.put("dataError","统计不可用："+ex.getMessage()); now.put("trend","数据暂缺"); }
                int eventRedCount=-1;
                try{
                    JSONArray es=f.optJSONArray("events");
                    boolean fetchedEvents=es!=null;
                    long eventTime=System.currentTimeMillis();
                    boolean dueEvents=oldItem==null || eventTime-oldItem.optLong("lastEventsAt",0L)>=(minute>=40?30_000L:60_000L) ||
                         (oldItem.optInt("h",h)!=h || oldItem.optInt("a",a)!=a);
                    if(es==null && dueEvents){
                        JSONObject eventResult=ApiClient.get("fixtures/events?fixture="+id,key);
                        apiCalls++;
                        es=eventResult.optJSONArray("response");
                        fetchedEvents=true;
                    }
                    if(!fetchedEvents){
                        // Event baseline is retained; no false red-card alert on a skipped call.
                        es=null;
                    }
                    JSONArray keys=new JSONArray();
                    Set<String> distinctReds=new HashSet<>();
                    if(es!=null)for(int j=0;j<es.length();j++){
                        JSONObject ev=es.optJSONObject(j);if(ev==null)continue;
                        String type=ev.optString("type");String detail=ev.optString("detail");
                        JSONObject time=ev.optJSONObject("time");
                        int at=time==null?0:time.optInt("elapsed");
                        JSONObject tm=ev.optJSONObject("team");JSONObject player=ev.optJSONObject("player");
                        String eventKey=type+":"+detail+":"+at+":"+(time==null?0:time.optInt("extra",0))+":"+(tm==null?0:tm.optInt("id"))+":"+(player==null?0:player.optInt("id"));
                        keys.put(eventKey);
                        if(isRedEvent(type,detail)){
                            // An API may describe one sending-off as both second
                            // yellow and red: dedupe by player/team/clock.
                            int teamId=tm==null?0:tm.optInt("id");
                            int playerId=player==null?0:player.optInt("id");
                            distinctReds.add(AlertPolicy.redEventIdentity(teamId,playerId,at,
                                time==null?0:time.optInt("extra",0),j));
                        }
                    }
                    if(fetchedEvents){
                        now.put("events",keys);now.put("lastEventsAt",eventTime);
                        eventRedCount=distinctReds.size();
                    }
                }catch(Exception ex){now.put("eventError","红牌事件暂不可用："+ex.getMessage());}
                // Compare one reconciled red-card total, AFTER both sources were
                // checked. If event data is unavailable, statistics alone still
                // triggers the alert; delayed events won't notify a second time.
                try{
                    int fromStats=countStatReds(now.optJSONObject("stats"));
                    int observed=AlertPolicy.combinedRedCount(fromStats,eventRedCount);
                    int oldBaseline=oldItem==null?0:oldItem.has("redNotifiedTotal")?
                        oldItem.optInt("redNotifiedTotal",0):
                        Math.max(0,countStatReds(oldItem.optJSONObject("stats")));
                    if(!firstCycle && oldItem!=null && !oldItem.has("redNotifiedTotal")){
                        oldBaseline=Math.max(oldBaseline,countOldRedEvents(oldItem));
                    }
                    if(AlertPolicy.newRedCard(firstCycle,oldItem!=null,oldBaseline,observed)){
                        int increased=observed-oldBaseline;
                        long alertAt=System.currentTimeMillis();
                        now.put("newRed",true).put("lastRedAt",alertAt)
                           .put("lastDisruptionAt",alertAt);
                        now.remove("aiReview");
                        AlertNotifier.post(this,"🟥 红牌 · 比赛人数变化",id,now,alertAt,
                            "全场已确认红牌数量增加"+increased+"张（统计/事件交叉去重），请核对球队和球员");
                    }
                    now.put("redNotifiedTotal",Math.max(oldBaseline,Math.max(0,observed)));
                    if(now.optBoolean("newRed",false)){
                        JSONArray fresh=new JSONArray();
                        fresh.put(new JSONObject().put("time",System.currentTimeMillis())
                            .put("minute",minute).put("stats",now.optJSONObject("stats")));
                        now.put("history",fresh);
                    }
                }catch(Exception ex){now.put("eventError","红牌合并校验失败："+ex.getMessage());}
                // The warning engine uses both ~5min and ~10min *observed* deltas.
                // The older single-threshold pressure notification is not emitted
                // as a second alert, avoiding duplicate/conflicting warnings.
                try {
                    long when=System.currentTimeMillis();
                    JSONObject warning=GoalWarningEngine.analyze(now,oldItem,when);
                    now.put("goalWarning",warning);
                    GoalWarningEngine.attachWindows(now,when);

                } catch(Exception e) {
                    now.put("goalWarning",new JSONObject().put("level","PASS").put("rating","PASS")
                        .put("title","预警运算失败").put("reason",e.getMessage()));
                }
                // A single user-provided exact score is evaluated independently of the
                // generic symmetric goal-warning engine. Missing odds never become estimates.
                try{
                    if(MainScoreRiskEngine.validPick(mainPick))
                        now.put("mainPickRisk",MainScoreRiskEngine.analyze(now,oldItem,mainPick,System.currentTimeMillis()));
                    else now.remove("mainPickRisk");
                }catch(Exception ex){now.put("mainPickRiskError",ex.getMessage());}
                // Only four checkpoints, confirmed goals and confirmed red cards are
                // allowed as automatic heads-up notifications in this companion app.
                // The risk engines remain for the existing screen and checkpoint detail,
                // but their independent notification paths are deliberately disabled.
                String riskType=null;
                java.util.ArrayList<Integer> marksSent=new java.util.ArrayList<>();
                try{
                    int oldMinute=oldItem==null?-1:oldItem.optInt("minute",-1);
                    for(int mark:AlertPolicy.MARKS){
                        if(AlertPolicy.checkpointDue(oldMinute,minute,mark)){
                            long seenAt=System.currentTimeMillis();
                            if(AlertNotifier.postMark(this,id,mark,now,seenAt))marksSent.add(mark);
                        }
                    }
                }catch(Exception e){now.put("notifyError",e.getMessage());}
                // Keep AI network latency OFF the single live polling thread:
                // data-backed alerts already fired above and AI revises the same banner.
                try{
                    String aiKey=pref.getString("openaiKey","").trim();
                    if(aiKey.isEmpty())now.remove("aiReview");
                    long aiNow=System.currentTimeMillis();
                    int aiCount=now.optInt("aiReviewCount",0);
                    boolean relevant=!marksSent.isEmpty();
                    if(!aiKey.isEmpty() && relevant && aiCount<10 &&
                       aiNow-now.optLong("lastStatsAt",0L)<=85_000L && !now.optBoolean("newRed") && aiSlots.tryAcquire()){
                        now.put("aiReviewAt",aiNow).put("aiReviewMinute",minute).put("aiReviewCount",aiCount+1);
                        pendingAi.add(new AiTask(id,aiKey,new JSONObject(now.toString()),riskType,marksSent,aiNow));
                        now.put("aiReviewError","AI复核已排队；风险通知不等待AI");
                    }
                }catch(Exception aiError){now.put("aiReviewError",aiError.getMessage());}
            } else {
                now.put("goalWarning",new JSONObject().put("level","PASS").put("rating","PASS").put("title","非上半场，暂停预警"));
                if(ended)now.put("trend","上半场已结束");
                if(!ended)now.put("trend","等待开赛");
            }
            if(AlertPolicy.goalOccurred(firstCycle,oldItem!=null,live,
                    oldItem==null?0:oldItem.optInt("h",0),oldItem==null?0:oldItem.optInt("a",0),h,a)){
                AlertNotifier.post(this,"⚽ 进球 · 比分更新",id,now,System.currentTimeMillis(),
                    "比赛比分变化，请核对实时赛事信息");
            }
            // Do not keep HT/2H/FT fixtures in analysis or watchlist.
            // They are still eligible for the one-off halftime notification above.
            if(!ended)next.put(now);
        }
        String remainingCsv=csv;
        if(!finishedIds.isEmpty()){
            JSONArray gone;
            try{gone=new JSONArray(pref.getString("autoPruned","[]"));}catch(Exception ex){gone=new JSONArray();}
            Set<String> prior=new HashSet<>();for(int q=0;q<gone.length();q++)prior.add(gone.optString(q));
            StringBuilder kept=new StringBuilder();
            for(String selected:csv.split(",")){
                if(finishedIds.contains(selected)){
                    if(prior.add(selected))gone.put(selected);
                }else if(!selected.isEmpty()){
                    if(kept.length()>0)kept.append(',');kept.append(selected);
                }
            }
            remainingCsv=kept.toString();
            // Avoid overwriting a concurrent user edit of the watchlist.
            if(csv.equals(pref.getString("watchIds",""))){
                pref.edit().putString("watchIds",remainingCsv).putString("autoPruned",gone.toString()).apply();
            }
            // Pending alarms are cancelled even if the watchlist changed while polling.
            ReminderReceiver.cancelFinished(this,finishedIds);
            // The user requested automatic deletion of *this fixture's* monitoring
            // history on true HT, with no collateral deletion of unrelated matches.
            AlertNotifier.purgeFinished(this,finishedIds);
        }
        JSONObject state=new JSONObject();
        state.put("updatedAt",System.currentTimeMillis()).put("matches",next)
             .put("interval",interval).put("apiCallsSession",apiCalls).put("error","");
        synchronized(snapshotLock){pref.edit().putString("snapshot",state.toString()).putString("lastError","").apply();}
        for(AiTask task:pendingAi){
            try{aiWorker.execute(()->completeAiTask(task));}
            catch(java.util.concurrent.RejectedExecutionException e){aiSlots.release();}
        }
        firstCycle=false;
        updateOngoingNotification(activeH+"场上半场进行中 · "+future+"场等待 · "+finishedH+"场已结束");
        // Stop when no fixtures remain; no automatic halftime push is sent.
        if(remainingCsv.isEmpty()){
            handler.post(()->{if(pref.getString("watchIds","").isEmpty())stopMonitor();});
        }
    }

    private void completeAiTask(AiTask task){
        JSONObject review=null;String problem="";
        try{review=AiReview.review(task.match,task.key);}
        catch(Exception e){problem="AI暂不可用："+e.getMessage();}
        try{
            JSONObject updated=null;
            synchronized(snapshotLock){
                JSONObject snapshot=new JSONObject(pref.getString("snapshot","{}"));
                JSONArray matches=snapshot.optJSONArray("matches");
                if(matches!=null)for(int i=0;i<matches.length();i++){
                    JSONObject current=matches.optJSONObject(i);
                    if(current==null || !task.id.equals(current.optString("id")))continue;
                    if(!pref.getBoolean("running",false) || !"1H".equals(current.optString("status")) ||
                        current.optInt("h",-1)!=task.match.optInt("h",-2) ||
                        current.optInt("a",-1)!=task.match.optInt("a",-2) ||
                        !current.optString("mainPick","").equals(task.match.optString("mainPick","")) ||
                        System.currentTimeMillis()-task.at>180_000L ||
                        current.optLong("lastStatsAt",0L)>task.match.optLong("lastStatsAt",0L)+90_000L)break;
                    if(review!=null){current.put("aiReview",review);current.remove("aiReviewError");}
                    else current.put("aiReviewError",problem);
                    pref.edit().putString("snapshot",snapshot.toString()).apply();
                    if(review!=null)updated=new JSONObject(current.toString());
                    break;
                }
            }
            if(updated!=null){
                // Update the in-app checkpoint/AI detail, not the Android banner.
                // A later AI reply must NEVER create an extra push or buzz for
                // an already-delivered 3/15/28/40-minute notification.
                for(int mark:task.marks){
                    AlertNotifier.saveCheckpoint(this,task.id,mark,updated,System.currentTimeMillis());
                }
            }
        }catch(Exception e){android.util.Log.w("HT","AI result merge failed",e);}
        finally{aiSlots.release();}
    }

    private static int valueOr(JSONObject side,String key){
        return side==null || side.isNull(key)?-1:side.optInt(key,-1);
    }
    private static boolean isRedEvent(String type,String detail){
        if(!"Card".equalsIgnoreCase(type) || detail==null)return false;
        String d=detail.toLowerCase(java.util.Locale.ROOT);
        return d.contains("red") || d.contains("second yellow");
    }
    private static int countStatReds(JSONObject stats){
        if(stats==null)return -1;
        JSONObject home=stats.optJSONObject("home"),away=stats.optJSONObject("away");
        boolean h=home!=null && home.has("red") && !home.isNull("red");
        boolean a=away!=null && away.has("red") && !away.isNull("red");
        if(!h && !a)return -1;
        return Math.max(0,h?home.optInt("red",0):0)+Math.max(0,a?away.optInt("red",0):0);
    }
    private static int countOldRedEvents(JSONObject old){
        if(old==null)return 0;
        JSONArray events=old.optJSONArray("events");
        if(events==null)return 0;
        Set<String> cards=new HashSet<>();
        for(int i=0;i<events.length();i++){
            String s=events.optString(i,"");
            if(!s.startsWith("Card:") || !isRedEvent("Card",s))continue;
            // Legacy keys use type:detail:minute:extra:team:player.
            // Reconcile duplicated second-yellow and red descriptions even
            // if a provider later adjusts the event's recorded minute.
            try{
                String[] parts=s.split(":");
                if(parts.length<6)throw new IllegalArgumentException("short key");
                int n=parts.length;
                int at=Integer.parseInt(parts[n-4]);
                int extra=Integer.parseInt(parts[n-3]);
                int team=Integer.parseInt(parts[n-2]);
                int player=Integer.parseInt(parts[n-1]);
                cards.add(AlertPolicy.redEventIdentity(team,player,at,extra,i));
            }catch(Exception ex){cards.add(s);}
        }
        return cards.size();
    }
    private void updateTrend(JSONObject now,JSONObject old,int minute)throws Exception{
        JSONObject stats=now.optJSONObject("stats");
        if(stats==null || !stats.optBoolean("available")){now.put("trend","统计缺失");return;}
        JSONArray history=old==null?null:old.optJSONArray("history");
        if(history==null)history=new JSONArray();
        JSONArray retained=new JSONArray();
        long nowTime=System.currentTimeMillis();
        for(int i=0;i<history.length();i++){
            JSONObject point=history.optJSONObject(i);
            if(point!=null && point.optLong("time")>=nowTime-12*60_000L && point.optInt("minute")<=minute)retained.put(point);
        }
        JSONObject sample=new JSONObject().put("time",nowTime).put("minute",minute).put("stats",stats);
        retained.put(sample);
        while(retained.length()>40){JSONArray reduced=new JSONArray();for(int i=1;i<retained.length();i++)reduced.put(retained.get(i));retained=reduced;}
        now.put("history",retained);
        JSONObject oldSample=null;
        for(int i=retained.length()-2;i>=0;i--){
            JSONObject p=retained.optJSONObject(i);
            if(p!=null && nowTime-p.optLong("time")>=4*60_000L && minute-p.optInt("minute")>=3){oldSample=p;break;}
        }
        if(oldSample==null){now.put("trend","积累5分钟样本中");now.remove("delta");return;}
        JSONObject past=oldSample.optJSONObject("stats");
        if(past==null){now.put("trend","等待统计");return;}
        double[] p=new double[2];
        JSONObject deltas=new JSONObject();
        String[] labels={"home","away"};
        for(int i=0;i<2;i++){
            JSONObject cur=stats.optJSONObject(labels[i]); JSONObject prev=past.optJSONObject(labels[i]);
            int on=valueOr(cur,"on"),box=valueOr(cur,"box"),shots=valueOr(cur,"shots");
            int prevOn=valueOr(prev,"on"),prevBox=valueOr(prev,"box"),prevShots=valueOr(prev,"shots");
            if(on<0||box<0||shots<0||prevOn<0||prevBox<0||prevShots<0){now.put("trend","射门统计不完整");return;}
            JSONObject d=new JSONObject();
            d.put("shots",Math.max(0,shots-prevShots));d.put("on",Math.max(0,on-prevOn));d.put("box",Math.max(0,box-prevBox));
            deltas.put(labels[i],d);
            p[i]=Math.max(0,on-prevOn)*1.1+Math.max(0,box-prevBox)*0.9+Math.max(0,shots-prevShots)*0.25;
        }
        String trend="攻守胶着";
        if(p[0]>=3 && p[0]>=p[1]+1.8)trend="主队近5分钟压制";
        else if(p[1]>=3 && p[1]>=p[0]+1.8)trend="客队近5分钟压制";
        else if(p[0]<0.8&&p[1]<0.8)trend="近5分钟机会较少";
        now.put("delta",deltas).put("trend",trend).put("pressureHome",Math.round(p[0]*10)/10.0).put("pressureAway",Math.round(p[1]*10)/10.0);
        now.put("trendWindowMinute",minute-oldSample.optInt("minute"));
    }
    private void record(String title,String detail){
        try{
            JSONArray previous=new JSONArray(pref.getString("alerts","[]"));
            JSONArray updated=new JSONArray();
            updated.put(new JSONObject().put("time",System.currentTimeMillis()).put("title",title).put("detail",detail));
            for(int i=0;i<Math.min(79,previous.length());i++)updated.put(previous.get(i));
            pref.edit().putString("alerts",updated.toString()).apply();
        }catch(Exception ignored){}
    }
    private void alert(String title,String msg){
        record(title,msg);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,ALERT_CHANNEL):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
         .setContentTitle(title).setContentText(msg).setStyle(new Notification.BigTextStyle().bigText(msg))
         .setAutoCancel(true).setContentIntent(openAppIntent()).setWhen(System.currentTimeMillis());
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(++notifyId,b.build());
    }
    private PendingIntent openAppIntent(){
        Intent i=new Intent(this,MainActivity.class);i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private Notification liveNotification(String content){
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,LIVE_CHANNEL):new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("HT 上半场监控正在运行")
                .setContentText(content).setOngoing(true).setContentIntent(openAppIntent()).build();
    }
    private void updateOngoingNotification(String text){
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(LIVE_ID,liveNotification(text));
    }
    private static void makeChannels(Context ctx){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager nm=(NotificationManager)ctx.getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel run=new NotificationChannel(LIVE_CHANNEL,"运行状态",NotificationManager.IMPORTANCE_LOW);
            run.setDescription("前台实时比赛监控状态");nm.createNotificationChannel(run);
            NotificationChannel urgent=new NotificationChannel(ALERT_CHANNEL,"定点、进球与红牌提醒",NotificationManager.IMPORTANCE_HIGH);
            urgent.setDescription("仅比赛第3/15/28/40分钟及进球、红牌");
            urgent.enableVibration(true);nm.createNotificationChannel(urgent);
        }
    }
    public static void testAlert(Context ctx){
        makeChannels(ctx);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(ctx,ALERT_CHANNEL):new Notification.Builder(ctx);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("HT 通知测试")
         .setContentText("如看到这条通知，系统通知通道可正常使用。").setAutoCancel(true);
        ((NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify(2985,b.build());
    }
    private void stopMonitor(){
        active=false;
        handler.removeCallbacksAndMessages(null);
        pref.edit().putBoolean("running",false).apply();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }
    @Override public void onDestroy(){
        active=false;handler.removeCallbacksAndMessages(null);
        worker.shutdownNow();aiWorker.shutdownNow();pref.edit().putBoolean("running",false).apply();
        super.onDestroy();
    }
    @Override public void onTimeout(int startId,int fgsType){
        if(Build.VERSION.SDK_INT>=35){record("后台监控到时","Android后台服务达到运行时限，请打开App重新启动。");stopMonitor();}
    }
}
