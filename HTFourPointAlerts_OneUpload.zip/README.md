# HT 四点提醒（独立版 v1.0.1 修正版）

以用户提供的 `HTLiveMonitor_v1_9_5_OneUpload.zip` 为基底，**完全保留**原始 `index.html` 页面、`import_parser.js` 截图导入引擎、Android 图片识别、Football API 与 AI API 的客户端和设置、比分输入、赛事选择、自动清理、详细数据展示。保留原有界面结构、图片 OCR、API 客户端和业务功能；仅更新用户可见的预警说明文字，避免继续显示已经关闭的攻势类推送描述。图片识别和 API 客户端文件与旧版本字节一致。

## 唯一的自动提醒（每场上半场）

- **第 3 分钟**：定点赛况提醒（比分、xG、射门、5/10 分钟趋势等可用数据）。
- **第 15 分钟**：同上。
- **第 28 分钟**：同上。
- **第 40 分钟**：同上。
- **进球**：当实时 API 的上半场比分相对上一份可信快照增加时提醒；不把取消进球/比分回调当成新进球。
- **红牌**：当红牌统计有可信增量，或 API 事件新增红牌时提醒；跨轮询周期对统计与事件中的同一张红牌按累计数量去重。

**完全停止其他自动提醒**：攻势/进球风险、主单准确比分风险、角球、任意球、黄牌、VAR、点球单独提醒、数据中断横幅、40分钟后额外提醒、43分钟补时提醒、半场结束通知。对应统计与分析依然保留在原有页面及四个定点详情里。主动点击测试通知按钮仍可测试 Android 通知权限；前台监控服务的持续运行状态通知仍须保留（这是系统要求，不算比赛预警）。

实际提醒时间以 API 赛事进程为准，而不是仅按预定开球时间推断；Android 系统省电、API 更新延迟可能造成晚提醒。节点最多允许约 2 分钟的比赛分钟窗口，并要求最近 60 秒内成功取得该场比赛的赛况；如果 Android 深度睡眠或 API 更新晚于窗口，则跳过过期提醒（可能漏报，避免误报）。开启多个 app 同时监控同一场比赛会独立请求 API，请注意调用配额。

## 两个 app 并行

原版 `applicationId = com.htlive.monitor.multimatch`。独立版 `applicationId = com.htlive.monitor.checkpoints`。应用显示名是 `HT 四点提醒（独立版）`。两个应用分别保存 API Key、图片和已选比赛，不会覆盖安装或共用监控记录。可以同时在一台 Android 手机上运行。

## GitHub 直接编译（一个 ZIP + 工作流）

新仓库建议命名 `HTFourPointGoalRedAlerts`，不要在原仓库操作。

1. 在 https://github.com/new 新建空仓库（建议 Private），选择 README/License 均不添加。
2. 在仓库根目录使用 **Add file → Upload files** 上传 `HTFourPointAlerts_OneUpload.zip`，提交。
3. 在 **Add file → Create new file**，文件路径填 `.github/workflows/build-apk.yml`，完整粘贴本次提供的 `build-apk.yml` 文件内容后提交。**GitHub 网页不会自动解压上传的 ZIP**；工作流会在构建机自动解压。
4. 进入 **Actions → Build HT Four Point Alerts APK → Run workflow**，构建完成后下载 `HTFourPointAlerts-debug-apk`，解压得到 `app-debug.apk`，安装到手机。与原版并存。

已有仓库无需新建：在仓库根目录直接替换同名 `HTFourPointAlerts_OneUpload.zip`，确保 `.github/workflows/build-apk.yml` 是附件里的修正版，推送或手动触发构建。修正版包名仍为 `com.htlive.monitor.checkpoints`、版本名升级为 `1.0.1-checkpoints`。**GitHub Actions 每次构建 Debug APK 可能换一把签名密钥，导致不能覆盖安装旧独立版；必要时只卸载旧“四点提醒”再安装新版，原版 `com.htlive.monitor.multimatch` 不受影响。卸载会清除该独立版中本地保存的 API Key、已选赛事、记录，请先备份所需设置。**

源码 ZIP 内同样附带 `.github/workflows/build-apk.yml` 备份，适用于在电脑上解压后以正常 Git 仓库方式上传（那种上传方式不需要放整包 ZIP）。

## 本地测试

```bash
for t in tests/*.test.js; do node "$t"; done
mkdir -p /tmp/ht-four-tests
javac -encoding UTF-8 -d /tmp/ht-four-tests app/src/main/java/com/htlive/monitor/AlertPolicy.java tests/java/com/htlive/monitor/AlertPolicyTest.java
java -cp /tmp/ht-four-tests com.htlive.monitor.AlertPolicyTest
javac -encoding UTF-8 -d /tmp/ht-four-tests tests/java/org/json/JSONObject.java app/src/main/java/com/htlive/monitor/MainScoreRiskEngine.java tests/java/com/htlive/monitor/MainScoreRiskEngineTest.java
java -cp /tmp/ht-four-tests com.htlive.monitor.MainScoreRiskEngineTest
```

**说明**：源码侧测试可运行；本地环境没有 Android SDK/Gradle，因此未直接生成或安装 APK。GitHub Actions 用于完成构建与安装验证。
